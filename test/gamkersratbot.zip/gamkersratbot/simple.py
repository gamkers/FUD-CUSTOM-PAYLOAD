from telegram.ext import Application, MessageHandler, filters

async def handle_command(update, context):
   
    user_message = update.message.text 
    print(user_message)
     # Get the user's message
    if "Hi" in user_message :
       await update.message.reply_text("hello how can i help you")  # Reply
    elif "Hello" in user_message:
         await update.message.reply_text("Hi")  # Reply
def main():
    app = Application.builder().token("7456059922:AAHPG-OTxBSLoslySTwnCdVC49V95wQYyAk").build()
    app.add_handler(MessageHandler(filters.TEXT, handle_command))
    app.run_polling()

if __name__ == "__main__":  
    main()
