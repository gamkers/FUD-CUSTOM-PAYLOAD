import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes, CallbackQueryHandler
import pyautogui
# Enable logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)

# Replace with your actual chat ID
ALLOWED_CHAT_ID = 1059393984

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /start is issued."""
    user = update.effective_user
    if update.effective_chat.id == ALLOWED_CHAT_ID:
        keyboard = [
            [InlineKeyboardButton("Information", callback_data='info'),
             InlineKeyboardButton("Description", callback_data='desc')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_html(
            f"Hi {user.mention_html()}! You're in the allowed chat. Choose an option:",
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text("Sorry, this bot is not available in this chat.")

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle button presses."""
    query = update.callback_query
    await query.answer()  # This acknowledges to Telegram that we've handled the query

    if query.data == 'info':
        await query.edit_message_text("This is a demo bot showcasing inline keyboard buttons and chat ID usage.")
    elif query.data == 'desc':
        await query.edit_message_text("This bot is designed for educational purposes to demonstrate Telegram bot features.")

async def send_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message to the specified chat ID."""
    if update.effective_chat.id == ALLOWED_CHAT_ID:
        keyboard = [
            [InlineKeyboardButton("Visit Telegram API Docs", url='https://core.telegram.org/bots/api')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await context.bot.send_message(
            chat_id=ALLOWED_CHAT_ID, 
            text="Here's a link you might find useful:",
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text("You're not authorized to use this command.")

async def screen_shot() -> None:
    """Take a screenshot and save it to disk."""
    screenshot = pyautogui.screenshot()
    screenshot_path = "screenshot.png"
    screenshot.save(screenshot_path)
    return screenshot_path

def main() -> None:
    """Start the bot."""
    application = Application.builder().token("7456059922:AAHPG-OTxBSLoslySTwnCdVC49V95wQYyAk").build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("send", send_message))
    application.add_handler(CallbackQueryHandler(button_callback))

    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()