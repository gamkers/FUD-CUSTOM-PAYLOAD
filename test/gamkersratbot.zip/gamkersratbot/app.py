
TELEGRAM_BOT_TOKEN = '7456059922:AAHPG-OTxBSLoslySTwnCdVC49V95wQYyAk'
TELEGRAM_CHAT_ID = '1059393984'
import requests

def send_to_telegram(package, title, text):
    url = f'https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage'
    message = f"Notification from: {package}\nTitle: {title}\nText: {text}"
    data = {
            'chat_id': TELEGRAM_CHAT_ID,
            'text': message
        }
    try:
        response = requests.post(url, data=data)
        if response.status_code == 200:
            print("Notification sent to Telegram successfully")
        else:
            print(f"Failed to send notification: {response.status_code}")
    except Exception as e:
        print(f"Error sending notification to Telegram: {e}")

send_to_telegram("test", "test", "test")