from pyht import Client, TTSOptions, Format
from pydub import AudioSegment
from pydub.playback import play
import io

# Initialize PlayHT API with your credentials
client = Client("9zY2ApgwBEeSjP9JwzrAvwnzeC82", "5fc6f9608d5f437593448130dc352878")

# Configure your stream
options = TTSOptions(
    voice="s3://voice-cloning-zero-shot/d9ff78ba-d016-47f6-b0ef-dd630f59414e/female-cs/manifest.json",
    sample_rate=44_100,
    format=Format.FORMAT_MP3,
    speed=1,
)

def talk(txt):
    male="s3://peregrine-voices/oliver_narrative2_parrot_saad/manifest.json"
    options = TTSOptions(voice="s3://voice-cloning-zero-shot/084070b5-e3d8-431c-a0b6-edb09d7356d0/vijay-actor/manifest.json")

    # Request text-to-speech conversion
    audio_generator = client.tts(txt, options)

    # Convert the generator to a list of bytes
    audio_bytes = b''.join(audio_generator)

    # Create an AudioSegment directly from the bytes
    audio = AudioSegment.from_file(io.BytesIO(audio_bytes), format='wav')

    # Play the audio
    play(audio)


talk("hello how are")