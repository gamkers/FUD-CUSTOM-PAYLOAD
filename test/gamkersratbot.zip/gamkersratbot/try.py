import pyautogui
import time
import subprocess
import re
from langchain.agents import Tool
from langchain import hub
from langchain.agents import AgentExecutor, create_react_agent
from langchain_groq import ChatGroq




def execute_shell_command(command):
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            return result.stdout
        else:
            return result.stderr
    except Exception as e:
        return str(e)

shell_command_tool = Tool(
    name="Execute shell command",
    func=execute_shell_command,
    description="Executes the provided shell command and returns the result. you need to provide the proper windows commands to this as argumnet"
)



# Load ReAct prompt
prompt_react = hub.pull("hwchase17/react")

# Initialize ChatGroq model for language understanding
model = ChatGroq(model_name="llama3-70b-8192", groq_api_key="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", temperature=0)

# Create ReAct agent
tools = [shell_command_tool]
react_agent = create_react_agent(model, tools=tools, prompt=prompt_react)
react_agent_executor = AgentExecutor(
    agent=react_agent, tools=tools, verbose=True, handle_parsing_errors=True
)

while True:
    input_string = input("how can i help you: ")
    if input_string:
        output = react_agent_executor.invoke({"input": input_string})
        print(output['output'])
