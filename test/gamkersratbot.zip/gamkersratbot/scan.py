from scapy.all import ARP, Ether, srp

def get_mac_and_ip(network_range):
    # Create an ARP request to broadcast across the network
    arp_request = ARP(pdst=network_range)
    broadcast = Ether(dst="ff:ff:ff:ff:ff:ff")
    arp_request_broadcast = broadcast / arp_request

    # Send the request and capture the response
    answered_list = srp(arp_request_broadcast, timeout=1, verbose=False)[0]

    devices = []
    for sent, received in answered_list:
        devices.append({'ip': received.psrc, 'mac': received.hwsrc})
    
    return devices
while True:
    # Network range (modify based on your network configuration)
    network_range = "192.168.1.1/24"  # Change this to your network range

    devices = get_mac_and_ip(network_range)

    # Print out all detected MAC and IP addresses
    for device in devices:
        if "b8:27:eb:99:54:16" in device['mac']:
            print(f"Raspberypi IP: {device['ip']}")
            break
