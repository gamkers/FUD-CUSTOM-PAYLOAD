import fitz
import requests
from io import BytesIO
from functools import lru_cache
from typing import List, Optional

from langchain.docstore.document import Document
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS

@lru_cache(maxsize=32)
def extract_text_from_pdf_url(pdf_url: str) -> Optional[str]:
    try:
        response = requests.get(pdf_url)
        response.raise_for_status()
        with fitz.open(stream=BytesIO(response.content), filetype="pdf") as pdf_document:
            return "".join(page.get_text() for page in pdf_document)
    except Exception as e:
        print(f"Error extracting text from PDF: {e}")
        return None

def create_document_chunks(text: str, chunk_size: int = 1000, chunk_overlap: int = 200) -> List[Document]:
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", " ", ""]
    )
    chunks = text_splitter.split_text(text)
    return [Document(page_content=chunk, metadata={"chunk_id": i}) for i, chunk in enumerate(chunks)]

def create_vector_store(documents: List[Document], model_name: str = "sentence-transformers/all-MiniLM-L6-v2") -> FAISS:
    embedding_model = HuggingFaceEmbeddings(model_name=model_name)
    return FAISS.from_documents(documents, embedding_model)

def answer_question(question: str, vector_store: FAISS, top_k: int = 3) -> List[Document]:
    return vector_store.similarity_search(question, k=top_k)

def pdftext(pdf_url):
    
    extracted_text = extract_text_from_pdf_url(pdf_url)
    
    if extracted_text:
        documents = create_document_chunks(extracted_text)
        vector_store = create_vector_store(documents)
        
        # Save the vector store
        vector_store.save_local("example_index")
        
        # Example usage
        question = "Creating a Function"
        answers = answer_question(question, vector_store)
        
        print(f"Top 3 most relevant chunks for the question: '{question}'")
        for i, answer in enumerate(answers, 1):
            print(f"\nChunk {i} (ID: {answer.metadata['chunk_id']}):")
            print(f"{answer.page_content}...")  # Print first 300 characters

if __name__ == "__main__":
    main()